UPDATE `#__update_sites`
   SET `name` = 'Joomla! Update Component'
 WHERE `name` = 'Joomla! Update Component Update Site';
